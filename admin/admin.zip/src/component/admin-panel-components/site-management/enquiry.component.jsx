// import ConfirmDelete from "../confirm-delete/confirm-delete";

const Enquiry = () => {

    return (
        <div style={{marginTop: '85px'}}>
            <div className="container-fluid m-auto">
                <h3>Enquiries</h3>
            </div>
        </div>
    )
}

export default Enquiry;