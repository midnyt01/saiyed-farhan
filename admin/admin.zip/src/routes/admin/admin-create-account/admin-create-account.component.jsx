import AdminCreateAccountForm from "../../../component/admin-panel-components/admin-create-account-form/admin-create-account-form.component";
import Topbar from "../../../component/admin-panel-components/admin-topbar/topbar.component";


const AdminCreateAccount = () => {
  return (
    <div>
        <Topbar />
        <AdminCreateAccountForm />
    </div>
  );
};
  
  export default AdminCreateAccount;