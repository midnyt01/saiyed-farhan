import Topbar from "../../../component/admin-panel-components/admin-topbar/topbar.component";
import Banners from "../../../component/admin-panel-components/admin-banner/admin-banner.component";

const BannerPage = () => {

    return (
        <div>
            <Topbar />
            < Banners />
        </div>
    )
}

export default BannerPage;