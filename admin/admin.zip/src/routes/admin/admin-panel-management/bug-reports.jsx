import Topbar from "../../../component/admin-panel-components/admin-topbar/topbar.component";
import BugReport from "../../../component/admin-panel-components/site-management/bug-reports.component";

const BugreportPage = () => {

    return (
        <div>
            <Topbar />
            < BugReport />
        </div>
    )
}

export default BugreportPage;